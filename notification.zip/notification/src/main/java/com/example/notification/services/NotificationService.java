package com.example.notification.services;

import org.thymeleaf.context.Context;

public interface NotificationService {

    void sendMessage(String to, String subject, String templateName, Context context, String topic);
}
