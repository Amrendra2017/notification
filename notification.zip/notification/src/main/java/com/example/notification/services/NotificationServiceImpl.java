package com.example.notification.services;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class NotificationServiceImpl implements NotificationService {


    @Autowired
    private FirebaseMessaging firebaseMessaging;

    @Autowired
    private TemplateEngine templateEngine;


    @Async
    public void sendMessage(String to, String subject, String templateName, Context context, String topic) {

        String notificationBody = templateEngine.process(templateName, context);
        System.out.println("Sending " + topic + " to : " + to);
        System.out.println("Body : " + notificationBody);
        try{
            Message message = Message.builder()
                                .setTopic(topic) // email/sms
                                .putData("body", notificationBody)
                                .build();

            String response = firebaseMessaging.send(message);
            System.out.println("successfully sent mail: " + response);


        } catch(FirebaseMessagingException ex) {
            System.out.println("Error sending " + topic + " : " + ex.getMessage()) ;
        }

    }
}
