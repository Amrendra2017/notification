package com.example.notification.controllers;

import com.example.notification.services.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.context.Context;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/email")
    public void sendEmail(@RequestParam("toEmail") String toEmail,
                          @RequestParam("subject") String subject,
                          @RequestParam("emailTemplate") String emailTemplate,
                          @RequestBody Context context) {
        notificationService.sendMessage(toEmail, subject, emailTemplate, context, "email");
    }

    @PostMapping("/sms")
    public void sendSms(@RequestParam("toSms") String toSms,
                          @RequestParam("smsTemplate") String smsTemplate,
                          @RequestBody Context context) {
        notificationService.sendMessage(toSms, "", smsTemplate, context, "sms");
    }

    @PostMapping("/all")
    public void sendSms(@RequestParam("toEmail") String toEmail,
                        @RequestParam("toSms") String toSms,
                        @RequestParam("subject") String subject,
                        @RequestParam("emailTemplate") String emailTemplate,
                        @RequestParam("smsTemplate") String smsTemplate,
                        @RequestBody Context context) {
        notificationService.sendMessage(toEmail, subject, emailTemplate, context, "email");
        notificationService.sendMessage(toSms, "", smsTemplate, context, "sms");
    }

    @PostMapping("/check")
    public String checkApi() {
        return "Notification API is up and running.";
    }

}
